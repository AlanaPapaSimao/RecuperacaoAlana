let Listachamada = ['Alice', 'Pedro', 'Jerson']
function addA(pos,aluno,x1){
    Listachamada.splice(pos,0,aluno)
    let pos1 = Listachamada.indexOf(x1)
    if(pos1 != -1){
        Listachamada.splice(pos1,1)
    }
    console.log(Listachamada)
}
addA(0,'Joana', 'Pedro')
addA(1,'Zilda', 'Jerson')