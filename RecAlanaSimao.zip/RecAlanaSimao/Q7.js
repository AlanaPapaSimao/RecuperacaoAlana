let listaEspera = ['J1', 'J2']
function newPart(){
    if (listaEspera.length < 3) {
        listaEspera.unshift('NovoJogador')
    }else{
         listaEspera.shift()
    }
    console.log(listaEspera)
}
newPart('J3')
newPart('J4')
newPart('J5')
newPart('J6')