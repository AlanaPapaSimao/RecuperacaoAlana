let arr = ['5:00 - Acordar', '6:00 - Lavar o rosto', '17:00 - Beber água']
function addEvento(pos,even1){
    arr.splice(pos,0,even1)
    console.log(arr)
}
function removeEvento(evento){
    pos = arr.indexOf(evento)
    if(pos != -1){
        arr.splice(pos,1)
    }
    console.log(arr)
}
addEvento(1,'7:30 - Exercício fisico')
removeEvento('17:00 - Beber água')