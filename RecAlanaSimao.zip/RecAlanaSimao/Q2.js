let clientes = ['Joao', 'Vitor', 'Mario']
let limite = 4
function adicionarCliente(cliente){
    clientes.unshift(cliente)
    if(clientes.length > limite){
        clientes.pop()
    }
    console.log(clientes)
}
adicionarCliente('Rita')
adicionarCliente('Marcela')
