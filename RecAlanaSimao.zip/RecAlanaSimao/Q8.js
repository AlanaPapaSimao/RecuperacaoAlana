let catalogo = ["L1", "L2", "L3", "L3"]
function ConfLivro(livro){
    pos = catalogo.indexOf(livro)
    if(pos != -1){
        console.log(catalogo.indexOf(livro))
    }else{
        console.log("Erro")
    }
}
ConfLivro("L2")