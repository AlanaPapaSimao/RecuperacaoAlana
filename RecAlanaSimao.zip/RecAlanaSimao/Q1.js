let carrinho1 = []
function addP(produto){
    carrinho1.push(produto)
    console.log(carrinho1)
}
function removerP(produto){
    carrinho1.pop(produto)
    console.log(carrinho1)
}
addP('Tenis')
addP('Vestido')
addP('Meia')
removerP()