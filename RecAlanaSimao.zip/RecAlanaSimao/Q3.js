let estoqueDePeca = ['A1', 'A2', 'A3']
function adicionarPeca(peca){
    estoqueDePeca.splice(1,0,peca)
    estoqueDePeca.pop
    console.log(estoqueDePeca)
}
adicionarPeca('A4')
adicionarPeca('A5')